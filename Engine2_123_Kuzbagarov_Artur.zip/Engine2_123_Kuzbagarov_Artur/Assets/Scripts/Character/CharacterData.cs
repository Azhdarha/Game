using UnityEngine;

public class CharacterData : MonoBehaviour
{
    [SerializeField] private CharacterController characterController;
    [SerializeField] private Transform characterTransform;
    [SerializeField] private float speed;

    public float DefaultSpeed => speed;
    public Transform CharacterTransform => characterTransform;
    public CharacterController CharacterController
    {
        get
        {
            return characterController;
        }
    }
}
