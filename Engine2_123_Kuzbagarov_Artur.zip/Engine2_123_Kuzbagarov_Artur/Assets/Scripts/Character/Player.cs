using UnityEngine;

public class PlayerCharacter : Character
{
    public override void Start()
    {
        base.Start();

        HealthComponent = new PlayerHealthComponent();
    }
    public override void Update()
    {
        if (!HealthComponent.IsAlive)
            return;

        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input. GetAxis("Vertical");

        Vector3 movementVector = new Vector3(moveHorizontal, 0, moveVertical).normalized;

        MovableComponent.Move(movementVector);
        MovableComponent.Rotation(movementVector);
    }
}
