using UnityEngine;
public interface ICharacterInput
{
    Vector3 MoveDirection { get; }
    bool IsAttack { get; }
}
