using UnityEngine;

public abstract class Character : MonoBehaviour 
{ 
    public  IMovable MovableComponent {get; protected set; }
    public IHealthComponent HealthComponent {get; protected set; }
    public IAttackComponent AttackComponent {get; protected set; }
    [SerializeField] protected CharacterData characterData;
    public CharacterData CharacterData => characterData;
    protected ICharacterInput input;


    public virtual void Start()
    {
        MovableComponent = new CharactertMovementComponent();
        MovableComponent.Initialize(characterData);
    } 
    public abstract void Update(); 
    public void Initialize(ICharacterInput input)
    {
        this.input = input;
    }

}