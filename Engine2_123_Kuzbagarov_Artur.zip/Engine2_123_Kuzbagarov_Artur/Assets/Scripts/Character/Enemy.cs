using UnityEngine;
public class EnemyCharacter : Character
{
    [SerializeField] private Character targetCharacter;
    [SerializeField] private AIState aiState;

    public override void Start()
    {
        base.Start();

        HealthComponent = new EnemyHealthComponent();
        AttackComponent = new CharacterAttackComponent();
        AttackComponent.Initialize(characterData);

        aiState = AIState.MoveToTarget;
    }
    
    public override void Update()
    {
        if (targetCharacter == null)
            return;

        float distance = Vector3.Distance(
            characterData.CharacterTransform.position,
            targetCharacter.transform.position
        );

        float attackRange = AttackComponent.AttackRange;

        switch (aiState)
        {
            case AIState.None:
                return;

            case AIState.MoveToTarget:
                if (distance <= attackRange)
                {
                    aiState = AIState.Attack;
                    return;
                }

                Move();
                return;

            case AIState.Attack:
                if (distance > attackRange)
                {
                    aiState = AIState.MoveToTarget;
                    return;
                }

                AttackComponent.MakeDamage(targetCharacter);
                return;
        }
    }

    private void Move()
    {
        Vector3 direction = targetCharacter.transform.position - characterData.CharacterTransform.position;
        direction = direction.normalized;

        MovableComponent.Move(direction);
        MovableComponent.Rotation(direction);
    }
}