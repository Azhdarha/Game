
using System;

public interface IHealthComponent
{
    public event Action OnDeath;
    public bool IsAlive {get; }
    public float Health { get; }
    public int MaxHealth { get; }
    public void GetDamage(float damage);
}
