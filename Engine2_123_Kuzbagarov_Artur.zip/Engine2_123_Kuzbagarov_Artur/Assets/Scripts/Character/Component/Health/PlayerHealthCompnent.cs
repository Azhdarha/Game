using System;
using System.Data;
using UnityEngine;
public class PlayerHealthComponent : IHealthComponent
{
    private float health = 50;
    public event Action OnDeath;
    public int MaxHealth => 50;

    public float Health
    {
        get => health;
        private set
        {
            health = value;
            if(health <= 0)
            {
                SetDeath();
                health = 0;
            }
        }
    }

    public bool IsAlive => health > 0;

    public void GetDamage(float damage)
    {
        Health -= damage;
        Debug.LogError($"Игрок получил {damage} урона. Осталось {Health}");
    }

    private void SetDeath()
    {
        OnDeath?.Invoke();
        Debug.LogError($"Осталось {Health}");
    }
}
