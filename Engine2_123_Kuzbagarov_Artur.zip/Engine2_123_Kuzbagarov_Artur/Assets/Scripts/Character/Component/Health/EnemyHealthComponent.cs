using System;
using UnityEngine;

public class EnemyHealthComponent : IHealthComponent
{
    private float health;
    public bool IsAlive => Health > 0;
    public int MaxHealth => 10;
    public float Health
    {
        get => health;
        private set
        {
            health = value;
            if(health <= 0)
            {
                health = 0;
                OnDeath?.Invoke();
            }
        }
    }

    public event Action OnDeath;

    public void GetDamage(float damage)
    {
        throw new NotImplementedException();
    }
}
